CHAP Links Library
==================

CHAP Links Library is a web based visualization library. 
The library is specially designed to be easy to use, to handle large amounts
of data, and to enable manipulation of the data.
The library consists of Graph, Graph3d, Network, Timeline, and Treegrid.

The tools are developed as 
[Google Visualization Charts](http://code.google.com/apis/visualization/documentation/gallery.html) 
for Javascript and GWT. 

Links Library is part of [CHAP](http://chap.almende.com), 
the Common Hybrid Agent Platform.
