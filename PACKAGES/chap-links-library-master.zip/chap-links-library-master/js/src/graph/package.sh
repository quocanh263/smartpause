#!/bin/sh

sh "../../tools/package.sh"
